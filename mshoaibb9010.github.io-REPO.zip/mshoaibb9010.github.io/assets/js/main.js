/* Small, dependency-free behaviour for the site.
   Everything here degrades safely: with JS off the page is fully readable. */

(function () {
  'use strict';

  var root = document.documentElement;
  var STORE_KEY = 'msb-theme';

  /* ---- colour theme -------------------------------------------------
     Default is whatever the operating system asks for. A click overrides
     it and the choice is remembered per browser. Storage can throw in a
     private window or with site data blocked, so every access is guarded. */

  function readStored() {
    try { return localStorage.getItem(STORE_KEY); } catch (e) { return null; }
  }

  function writeStored(value) {
    try { localStorage.setItem(STORE_KEY, value); } catch (e) { /* not fatal */ }
  }

  var stored = readStored();
  if (stored === 'dark' || stored === 'light') {
    root.setAttribute('data-theme', stored);
  }

  var toggle = document.querySelector('.theme');
  if (toggle) {
    toggle.addEventListener('click', function () {
      var systemDark = window.matchMedia &&
                       window.matchMedia('(prefers-color-scheme: dark)').matches;
      var current = root.getAttribute('data-theme') || (systemDark ? 'dark' : 'light');
      var next = current === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      writeStored(next);
      toggle.setAttribute('aria-label',
        next === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    });
  }

  /* ---- footer year --------------------------------------------------- */

  var year = document.getElementById('year');
  if (year) { year.textContent = String(new Date().getFullYear()); }

  /* ---- nav highlighting ----------------------------------------------
     Marks the nav link for whichever section is currently in view. Uses
     IntersectionObserver where available and simply does nothing where
     it is not — the links still work either way. */

  var links = Array.prototype.slice.call(document.querySelectorAll('.nav a[href^="#"]'));
  if (!links.length || !('IntersectionObserver' in window)) { return; }

  var byId = {};
  var sections = [];

  links.forEach(function (link) {
    var id = link.getAttribute('href').slice(1);
    var section = document.getElementById(id);
    if (section) {
      byId[id] = link;
      sections.push(section);
    }
  });

  var visible = {};

  function paint() {
    var active = null;
    for (var i = 0; i < sections.length; i++) {
      if (visible[sections[i].id]) { active = sections[i].id; break; }
    }
    links.forEach(function (link) {
      if (active && link === byId[active]) {
        link.setAttribute('aria-current', 'true');
      } else {
        link.removeAttribute('aria-current');
      }
    });
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      visible[entry.target.id] = entry.isIntersecting;
    });
    paint();
  }, { rootMargin: '-78px 0px -55% 0px', threshold: 0 });

  sections.forEach(function (section) { observer.observe(section); });
}());
